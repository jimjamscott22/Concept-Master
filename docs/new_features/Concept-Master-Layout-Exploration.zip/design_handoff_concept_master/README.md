# Handoff: Concept Master — Layout & Theme Rework

## Overview

Concept Master is a desktop reference/study app for technical concepts (definitions, code samples, diagrams). This handoff covers a readability-focused rework of the **Browse** experience plus a new **Diagram** (concept map) page.

Three things ship together:

1. **Three switchable layouts** — three-pane, two-pane, and a centered reading view.
2. **Five themes** — Midnight (refined dark), Paper, Sepia, Ocean Blue, High Contrast.
3. **A typography mode toggle** — all-monospace vs. monospace chrome + serif body prose.

The problems being solved, from the original app (`current-app-screenshot.png`):

- Contrast was too low / too dark.
- Three competing panes crowded the reading column.
- **Tags were nearly invisible**, buried at the bottom of list cards and absent from the reader header.

## About the Design Files

`Concept Master.dc.html` in this bundle is a **design reference created in HTML** — a working prototype that demonstrates the intended look, layout, states and interactions. It is **not production code to copy**. It is a single self-contained file that renders through a lightweight prototyping runtime (a template + a logic class); its structure does not map onto a production component tree.

The task is to **recreate these designs in the target codebase's existing environment** (React, Vue, SwiftUI, native, etc.) using its established patterns, component library, styling approach, and routing. If no environment exists yet, pick the most appropriate framework for the project and implement there. Lift the *values* (colors, sizes, spacing, copy, behavior) from this document and from the prototype; do not lift the prototype's file format.

To view the prototype: open `Concept Master.dc.html` in a browser (it needs network access for Google Fonts). Everything is clickable — switch themes with the swatches at the top right, layouts with the three icons beside them, typography with the `Aa` button.

## Fidelity

**High-fidelity.** Colors, typography, spacing, borders and interaction states are final and specified exactly below. Recreate pixel-perfectly using the codebase's existing primitives where they exist. The only intentionally rough parts:

- The **Diagram tab** inside a concept renders labeled horizontal bars as a stand-in for real diagrams/illustrations. Treat it as a placeholder container with a caption + rows, not as final art.
- **Articles / Study / Review / Stats** pages are empty states in the prototype — out of scope, keep whatever exists in the app today.
- The concept dataset (17 terms) is sample content. Real data comes from the app's store.

---

## Global Chrome

### Header (all pages)

- Height **56px**, `position: sticky; top: 0; z-index: 40`.
- Background `var(--bg2)`, bottom border `1px solid var(--line)`.
- `display: flex; align-items: center; gap: 22px; padding: 0 18px`.

Children, left to right:

1. **Logo** — `> concept-master`. `flex` row, `gap: 9px`, `font-weight: 700`, `letter-spacing: -0.01em`, `white-space: nowrap`. The `>` is `var(--accent)`; the wordmark is `var(--fg)`.
2. **Search trigger** (button, not an input) — `width: 220px; min-width: 150px; flex-shrink: 1; height: 34px; padding: 0 12px`, `background: var(--bg)`, `1px solid var(--line)`, `border-radius: 7px`, `font-size: 13px`, `color: var(--fg3)`. Contents: `⌕` glyph, the label `Search terms…` (flex: 1, left aligned), and a `CTRL+K` chip (`font-size: 10.5px`, `1px solid var(--line)`, `border-radius: 4px`, `padding: 1px 5px`). Hover: border → `var(--accent)`, text → `var(--fg2)`. Click opens the command palette.
3. **Nav** — `flex: 1; min-width: 0; overflow-x: auto` with the scrollbar hidden (`scrollbar-width: none` + `::-webkit-scrollbar { display: none }`), `gap: 2px`. Items scroll rather than clip on narrow desktop widths.
   Items: `01 BROWSE`, `02 DIAGRAM`, `03 ARTICLES`, `04 STUDY`, `05 REVIEW` (+`99+` badge), `06 STATS`.
   Each button: `height: 34px; padding: 0 9px; flex: none; white-space: nowrap; border: none; border-radius: 6px; font-size: 12.5px; letter-spacing: .08em`. The two-digit number prefix is `opacity: .5; font-size: 10.5px; margin-right: 7px`.
   - Inactive: `background: transparent; color: var(--fg3); font-weight: 400`. Hover → `color: var(--fg)`.
   - Active: `background: var(--bg3); color: var(--fg); font-weight: 600`.
   - Badge (`99+`): `margin-left: 8px; font-size: 10px; color: var(--accent2); border: 1px solid var(--line); border-radius: 4px; padding: 1px 5px`.
4. **Control cluster** — `flex: none`, `gap: 8px`. Three groups:
   - **Layout switcher**: 3 icon buttons in a `var(--bg)` container with `1px solid var(--line)`, `border-radius: 7px`, `padding: 3px`, `gap: 2px`. Each button `30 × 24px`, `border-radius: 5px`, `font-size: 13px`, no border. Icons `▥` (three-pane), `▤` (two-pane), `▭` (centered), with `title` tooltips. Selected: `background: var(--bg3); color: var(--accent)`. Unselected: transparent / `var(--fg3)`.
   - **Type toggle**: `height: 30px; padding: 0 11px; border-radius: 7px; 1px solid var(--line); background: var(--bg); color: var(--fg2); font-size: 11.5px; letter-spacing: .04em`. Label is `Aa SERIF BODY` in hybrid mode, `Aa ALL MONO` in mono mode (the label states the *current* mode). Hover: border → `var(--accent)`, text → `var(--fg)`.
   - **Theme swatches**: container `background: var(--bg); 1px solid var(--line); border-radius: 7px; padding: 4px 6px; gap: 5px`. Each swatch is an `18 × 18px` circle whose fill previews the theme. Unselected: `1px solid var(--line)`. Selected: `2px solid <theme ring color>` plus `box-shadow: 0 0 0 2px var(--bg2)`. Order and fills: Midnight `#0f1216`, Paper `#faf9f7`, Sepia `#f0e3c8`, Ocean Blue `#cfe6f7`, High contrast `#000`. Ring colors: `#7cc4ff`, `#0b62c4`, `#9a5b1f`, `#0a6ea8`, `#ffd400`.

### Command palette (all layouts)

Opened by the header search button, the floating pill in centered layout, or `Ctrl/Cmd+K`. Closed by `Escape` or clicking the backdrop.

- Backdrop: `position: fixed; inset: 0; background: rgba(0,0,0,.55); backdrop-filter: blur(3px); z-index: 80`, content aligned to top with `padding-top: 12vh`.
- Panel: `width: 620px; max-width: 92vw; background: var(--bg2); 1px solid var(--line); border-radius: 12px; box-shadow: 0 24px 70px rgba(0,0,0,.45); overflow: hidden`.
- Input: full width, `height: 52px; padding: 0 18px`, transparent background, no border except `border-bottom: 1px solid var(--line)`, `font-size: 15px`, autofocused. Placeholder: `Search terms, tags, categories…`.
- Results: `max-height: 56vh; overflow-y: auto; overflow-x: hidden; padding: 8px`. Each row: full width, `padding: 10px 12px; border-radius: 7px; font-size: 13.5px`, term name on the left (truncates with ellipsis), category right-aligned at `font-size: 11px; color: var(--fg3)`. Hover: `background: var(--bg3)`. Click selects the term, switches to Browse, resets the tab to Definition, and closes the palette.
- Filter matches term name, category, or any tag (case-insensitive, substring). Capped at 40 results.

---

## Screens / Views

### 1. Browse — three-pane layout (`layout: "three"`)

**Purpose:** scan categories, skim terms, read the selected term. The retuned version of today's app.

Container: `display: flex; height: calc(100vh - 56px); overflow: hidden`.

**Pane A — Category sidebar.** `width: 232px; flex: none; border-right: 1px solid var(--line); background: var(--bg2); overflow-y: auto; padding: 18px 0 40px`.
- Section labels (`FILTERS`, `CATEGORIES`): `padding: 0 16px 10px; font-size: 10.5px; letter-spacing: .14em; color: var(--fg3)`.
- `★ Favorites only` toggle: `width: calc(100% - 16px); margin: 0 8px; padding: 8px 10px; border-radius: 6px; font-size: 13px`. Off: transparent background, `1px solid transparent`, `color: var(--fg2)`. On: `background: var(--bg3)`, `1px solid var(--accent)`, `color: var(--accent)`.
- Divider: `height: 1px; background: var(--line); margin: 16px 16px`.
- Category rows (`All` first, then alphabetical): `width: 100%; padding: 8px 10px; border-radius: 6px; font-size: 13px`, name left, count right (`font-size: 11px; color: var(--fg3)`). Inactive: transparent, `color: var(--fg2)`, `border-left: 2px solid transparent`. Active: `background: var(--bg3)`, `color: var(--fg)`, `border-left: 2px solid var(--accent)`. Rows are stacked with `gap: 1px` inside `padding: 0 8px`.

**Pane B — Term list.** `width: 336px; flex: none; border-right: 1px solid var(--line); background: var(--bg2); display: flex; flex-direction: column; overflow: hidden`.
- Result header strip: `padding: 11px 16px; border-bottom: 1px solid var(--line); font-size: 11px; letter-spacing: .1em; color: var(--fg3)`, `display: flex; justify-content: space-between`. Left `"<n> TERMS"`, right the active category uppercased (`ALL CATEGORIES` when unfiltered).
- Scrollable list of cards. Each card: `width: 100%; padding: 15px 16px; text-align: left; border: none; border-bottom: 1px solid var(--line); border-left: 3px solid transparent`. Selected card: `background: var(--bg3); border-left-color: var(--accent)`.
  - Row 1: term name (`font-weight: 600; font-size: 14.5px; color: var(--fg); letter-spacing: -0.01em`) and, right-aligned, an optional `VISUAL` chip (`font-size: 9.5px; letter-spacing: .1em; 1px solid var(--tag-line); color: var(--tag-fg); border-radius: 3px; padding: 1px 5px`) + a star (`font-size: 13px`; favorited `var(--accent)` at full opacity, otherwise `var(--fg3)` at `opacity: .5`).
  - Row 2: summary, `margin-top: 5px; color: var(--fg2); font-size: 12.5px; line-height: 1.55`, clamped to **2 lines** (`-webkit-line-clamp: 2`).
  - Row 3 (**the tag fix**): `margin-top: 9px`, wrapping `flex` with `gap: 5px`. Each tag: `font-size: 10.5px; color: var(--tag-fg); background: var(--tag-bg); 1px solid var(--tag-line); border-radius: 4px; padding: 2px 7px`.

**Pane C — Reader.** `flex: 1; overflow-y: auto; background: var(--bg)`; inner article `max-width: 900px; margin: 0; padding: 34px 44px 90px`. See "Reader content" below.

### 2. Browse — two-pane layout (`layout: "two"`)

Sidebar is dropped. The list column widens to **380px** and gains a **category chip rail** at its top: `padding: 12px 14px; border-bottom: 1px solid var(--line); background: var(--bg2); gap: 6px; overflow-x: auto`. Each chip: `flex: none; padding: 5px 11px; border-radius: 999px; font-size: 11.5px; white-space: nowrap`, count appended at `opacity: .55`. Inactive: `1px solid var(--line)`, transparent, `color: var(--fg2)`. Active: `1px solid var(--accent)`, `background: var(--bg3)`, `color: var(--fg)`. `Favorites only` is not present in this layout (palette + chips carry filtering). Reader identical to three-pane.

### 3. Browse — centered reading view (`layout: "center"`)

Both left panes are dropped. The reader fills the viewport: inner article `max-width: 820px; margin: 0 auto; padding: 56px 40px 100px`.

Navigation happens through the palette, so a **floating pill** appears: `position: fixed; right: 26px; bottom: 26px; z-index: 50; height: 46px; padding: 0 20px; border-radius: 26px; 1px solid var(--line); background: var(--bg2); color: var(--fg2); font-size: 13px; box-shadow: 0 10px 30px rgba(0,0,0,.28)`. Contents: `⌕`, `Jump to term`, and a `CTRL+K` chip. Hover: border → `var(--accent)`, text → `var(--fg)`.

### Reader content (all Browse layouts)

Top block, `display: flex; justify-content: space-between; gap: 24px; align-items: flex-start`:

- **Left — metadata above the title** (the second half of the tag fix). `margin-bottom: 14px`, wrapping flex, `gap: 8px`:
  - Category pill: `font-size: 11px; letter-spacing: .12em; font-weight: 600; border-radius: 4px; padding: 3px 9px; background: var(--accent); color: var(--bg2)`.
  - Tag pills: `#tagname`, `font-size: 11.5px; color: var(--tag-fg); background: var(--tag-bg); 1px solid var(--tag-line); border-radius: 4px; padding: 3px 9px`.
  - Optional `HAS DIAGRAM` marker: `font-size: 10.5px; letter-spacing: .1em; color: var(--fg3); border: 1px dashed var(--line); border-radius: 4px; padding: 3px 8px`.
  - Title `h1`: `font-size: 34px; line-height: 1.15; letter-spacing: -0.025em; font-weight: 700; margin: 0`.
- **Right — actions**, `gap: 7px`, `flex: none`: star button (`32 × 32px; border-radius: 6px; 1px solid var(--line); background: var(--bg2)`; `var(--accent)` when favorited, else `var(--fg3)`), then `Edit` and `Delete` (`height: 32px; padding: 0 14px; border-radius: 6px; 1px solid var(--line); background: var(--bg2); font-size: 12.5px`; `Edit` text `var(--fg2)`, `Delete` text `var(--fg3)`; hover → `var(--fg)`, `Edit` also borders `var(--accent)`).

**Tab bar:** `margin: 26px 0 0; border-bottom: 1px solid var(--line); gap: 4px`. Tabs are `Definition ALT+1`, `Code ALT+2`, and `Diagram ALT+3` (only when the term has diagram data). Each: `padding: 11px 16px; font-size: 12.5px; letter-spacing: .04em; margin-bottom: -1px`. Inactive: `color: var(--fg3); border-bottom: 2px solid transparent`. Active: `color: var(--fg); font-weight: 600; border-bottom: 2px solid var(--accent)`. The shortcut hint is `opacity: .45; font-size: 10.5px; margin-left: 8px`. (Shortcut hints are displayed; wiring the actual Alt keys is optional — only `Ctrl/Cmd+K` and `Escape` are bound in the prototype.)

**Definition tab.** `padding-top: 26px; max-width: 68ch; font-family: var(--body); font-size: var(--bodysize); line-height: var(--bodylh); color: var(--fg); text-wrap: pretty`. Two block types:
- Paragraph: `margin: 0 0 18px`, optional eyebrow label above it (`font-family: var(--ui); font-size: 11px; letter-spacing: .14em; color: var(--fg3); margin-bottom: 6px`).
- Callout: `margin: 20px 0; padding: 14px 18px; background: var(--bg2); 1px solid var(--line); border-radius: 8px` (same eyebrow treatment inside).

Inline formatting inside prose: **bold** → `font-weight: 700`; *italic* → `font-style: italic`; `inline code` → `font-family: var(--ui); font-size: 0.86em; color: var(--accent); background: var(--bg2); 1px solid var(--line); border-radius: 4px; padding: 1px 5px`. ⚠️ Inline runs must be emitted with **no whitespace between them**, or spaces appear before punctuation.

Below the prose, a **Related** block: `margin-top: 34px; padding-top: 20px; border-top: 1px solid var(--line)`, eyebrow `RELATED`, then wrapping chips `gap: 8px`: `font-family: var(--ui); font-size: 12.5px; color: var(--fg2); background: var(--bg2); 1px solid var(--line); border-radius: 6px; padding: 6px 12px`, with a trailing `→` in `var(--fg3)`. Hover: border → `var(--accent)`, text → `var(--fg)`. Clicking navigates to that term.

**Code tab.** `padding-top: 22px`. Language tabs (`gap: 6px; margin-bottom: 12px`): `padding: 6px 13px; border-radius: 6px; font-size: 12px`; selected `1px solid var(--accent)`, `background: var(--bg3)`, `color: var(--fg)`; unselected `1px solid var(--line)`, transparent, `color: var(--fg3)`. Languages present in the sample data: Python, Java, JavaScript, SQL — a term exposes only the ones it has, and the first is the default.
Code block: `background: var(--code-bg); 1px solid var(--line); border-radius: 10px; padding: 20px 22px; overflow-x: auto`; `pre` is `font-family: var(--ui); font-size: 13.5px; line-height: 1.75; color: var(--c-txt)`. Syntax highlighting uses the `--c-*` tokens (see below) — in production, use the codebase's existing highlighter (Shiki/Prism/highlight.js) with a theme mapped to those tokens rather than porting the prototype's tokenizer.

**Diagram tab (placeholder).** `padding-top: 22px`; card `1px solid var(--line); border-radius: 10px; background: var(--bg2); padding: 28px`. Caption eyebrow, then rows `gap: 14px`: a `150px` right-aligned label (`font-size: 12.5px; color: var(--fg2)`), then a `34px`-tall track (`background: var(--bg3); 1px solid var(--line); border-radius: 6px`) containing a percentage-width fill (`background: var(--sel); border-right: 2px solid var(--accent)`) and an overlaid note (`padding-left: 12px; font-size: 12px; color: var(--fg)`).

### 4. Diagram page — concept map

**Purpose:** see the whole corpus at once, grouped by topic, and jump into any term.

`height: calc(100vh - 56px); overflow-y: auto; padding: 34px 40px 70px`; inner wrapper `max-width: 1280px; margin: 0 auto`.

- Header row (`flex`, `justify-content: space-between`, `align-items: flex-end`, wraps): `h1` "Concept map" at `font-size: 30px; letter-spacing: -0.025em`, subtitle `margin-top: 8px; color: var(--fg2); font-size: 13.5px; line-height: 1.6; max-width: 60ch` — "Every term grouped by topic. Chip weight shows how many other concepts link to it — click any chip to open it in Browse."
- Legend, right side: 3 items, each `1px solid var(--line); border-radius: 6px; padding: 5px 10px; font-size: 11.5px; color: var(--fg3); gap: 7px`, with a `9 × 9px` marker — `Core term` (circle, `var(--accent)`), `Has diagram` (circle, `var(--accent2)`), `Favorited` (2px-radius square, `var(--tag-fg)`).
- Grid: `display: grid; grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); gap: 16px; margin-top: 26px; align-items: start`.
- One card per category: `1px solid var(--line); border-radius: 12px; background: var(--bg2); overflow: hidden`.
  - Header: `padding: 13px 16px; border-bottom: 1px solid var(--line); background: var(--bg3)`; a `9px` accent dot + category name (`font-weight: 600; font-size: 13.5px`) on the left, `"<n> terms"` (`font-size: 11px; color: var(--fg3)`) on the right.
  - Body: wrapping chips, `gap: 7px; padding: 14px 16px 16px`. Each chip: `padding: 6px 11px; border-radius: 6px; font-family: var(--ui)`. **Font size encodes connectedness**: `11.5px + min(3, relatedCount)px` → 11.5–14.5px. `background: var(--bg3)` if the term has diagram data, else transparent. Border `var(--tag-line)` if favorited, else `var(--line)`. Color `var(--accent)` if it is the currently selected term, else `var(--fg2)`. Hover: border → `var(--accent)`, text → `var(--fg)`. Click → open in Browse.

### 5. Stub pages (Articles / Study / Review / Stats)

Centered column, `color: var(--fg3)`: the nav label at `font-size: 13px; letter-spacing: .16em`, the line "Not part of this layout exploration." at `12.5px`, and a `← Back to Browse` button (`padding: 8px 16px; border-radius: 6px; 1px solid var(--line); background: var(--bg2); font-size: 12.5px`). Replace with the app's real pages.

---

## Interactions & Behavior

- **Theme swatch click** → sets the active theme; all colors come from CSS custom properties, so nothing else needs to re-render. The prototype applies it as `data-theme` on `<html>`; in production, whatever theming mechanism the app already has is fine, as long as the token names/values match.
- **Layout icon click** → switches between three-pane / two-pane / centered. The reader is always mounted; only the two left panes and the reader's `max-width`/`margin`/`padding` change.
- **Type toggle click** → flips `data-type` between `mono` and `hybrid`, which swaps `--body`, `--bodysize`, `--bodylh`. Only body prose changes; all chrome stays monospace.
- **Term selection** (list card, related chip, palette row, map chip) → sets the selected term, forces `page: browse`, resets the content tab to Definition and the language tab to the term's first language.
- **Category selection** (sidebar row or chip rail) → filters the list; `All` clears it.
- **Favorites** — star on a list card is display-only; the star button in the reader header toggles. `Favorites only` filters the list. Favorites also change map chip borders.
- **Keyboard**: `Ctrl/Cmd+K` opens the palette and clears the query; `Escape` closes it. Displayed-only: `ALT+1/2/3` for content tabs.
- **Filtering** is a case-insensitive substring match on name, category, or tags. List filters compose: category → favorites → query.
- **Transitions**: none in the prototype. If the codebase has a motion standard, a ~120ms color/background transition on hover states and a fade on the palette backdrop are appropriate; don't animate layout switches.
- **Responsive**: desktop only. The nav scrolls horizontally (scrollbar hidden) and the search button shrinks so the right-hand control cluster is never clipped. No breakpoints below tablet.

## State Management

| State | Type | Default | Notes |
|---|---|---|---|
| `theme` | `'dark' \| 'paper' \| 'sepia' \| 'ocean' \| 'contrast'` | `contrast` | persist per user |
| `layout` | `'three' \| 'two' \| 'center'` | `center` | persist per user |
| `typeMode` | `'hybrid' \| 'mono'` | `hybrid` | persist per user |
| `page` | nav id | `browse` | route, not local state, in production |
| `selected` | concept id | first concept | route param in production |
| `tab` | `'def' \| 'code' \| 'visual'` | `def` | resets on term change |
| `lang` | language name \| null | null → term's first language | falls back if the term lacks the language |
| `category` | category name \| `'All'` | `All` | |
| `favOnly` | boolean | false | |
| `favs` | `Record<conceptId, boolean>` | — | server-persisted in production |
| `query` | string | `''` | palette query; cleared on open |
| `paletteOpen` | boolean | false | |

The prototype's defaults (High Contrast + centered) are the user's chosen starting point, not necessarily the product default — pick sensible product defaults (Midnight + three-pane matches today's app) and let preferences override.

**Data shape** each concept needs: `id`, `name`, `category`, `tags: string[]`, `visual: boolean`, `related: id[]`, `summary`, `blocks: { type: 'p' | 'callout', label?, text }[]` (text supports `**bold**`, `*italic*`, `` `code` ``), `code: Record<language, string>`, and optional `visualCaption` / `visualRows: { label, note, pct }[]`. Category counts are derived. No data fetching is modeled; the prototype uses an in-file array of 17 terms.

## Design Tokens

Every color is a CSS custom property; the five themes redefine the same set.

| Token | Role |
|---|---|
| `--bg` | app background / reader surface |
| `--bg2` | header, panes, cards, callouts |
| `--bg3` | active/selected surface, hover fill |
| `--line` | all borders and dividers |
| `--fg` / `--fg2` / `--fg3` | primary text / secondary / tertiary + labels |
| `--accent` | primary accent (active states, links, category pill) |
| `--accent2` | secondary accent (badges, "has diagram") |
| `--sel` | text selection + diagram bar fill |
| `--code-bg` | code block background |
| `--tag-bg` / `--tag-fg` / `--tag-line` | tag pill fill / text / border |
| `--c-kw` `--c-str` `--c-num` `--c-com` `--c-fn` `--c-txt` | syntax: keyword, string, number, comment, function/decorator, plain |

**Midnight (dark)** — `--bg #0f1216` · `--bg2 #151a21` · `--bg3 #1c232c` · `--line #2b333e` · `--fg #e9eef4` · `--fg2 #a9b6c4` · `--fg3 #7c8a99` · `--accent #7cc4ff` · `--accent2 #9ae6b4` · `--sel #27405a` · `--code-bg #0a0d11` · `--tag-bg #1d2733` · `--tag-fg #9fd0ff` · `--tag-line #2f4356` · syntax `#82aaff #c3e88d #f78c6c #6b7c8f #ffcb6b #dbe4ee`

**Paper (light)** — `--bg #faf9f7` · `--bg2 #f2f0ec` · `--bg3 #e9e6e0` · `--line #ddd7cd` · `--fg #1a1c1f` · `--fg2 #4c525a` · `--fg3 #787f88` · `--accent #0b62c4` · `--accent2 #0f7a52` · `--sel #cfe2fb` · `--code-bg #f5f3ef` · `--tag-bg #e7edf6` · `--tag-fg #12508a` · `--tag-line #c9d8ec` · syntax `#0b62c4 #0f7a52 #a03a12 #8a8f96 #7a3ea8 #24272b`

**Sepia (warm, low-strain)** — `--bg #f5eddd` · `--bg2 #eee4ce` · `--bg3 #e5d9bf` · `--line #d9caab` · `--fg #2e2921` · `--fg2 #5c5243` · `--fg3 #867b67` · `--accent #9a5b1f` · `--accent2 #4f6b3a` · `--sel #e2cea0` · `--code-bg #f0e6d2` · `--tag-bg #e8dec4` · `--tag-fg #7a4a13` · `--tag-line #d3c09b` · syntax `#9a5b1f #4f6b3a #8a3324 #9c9078 #6b4f9a #37312a`

**Ocean Blue (light sky)** — `--bg #f2f8fd` · `--bg2 #e6f1fa` · `--bg3 #d8e9f6` · `--line #bcd8ec` · `--fg #0f2a3d` · `--fg2 #3c5f78` · `--fg3 #6d8ba1` · `--accent #0a6ea8` · `--accent2 #0f8f8f` · `--sel #bfe0f5` · `--code-bg #eaf3fb` · `--tag-bg #dbecf8` · `--tag-fg #0a5c8c` · `--tag-line #b3d5ec` · syntax `#0a6ea8 #0f7a63 #a2521a #7d97a9 #6a4fa3 #17384f`

**High contrast** — `--bg #000` · `--bg2 #0c0c0c` · `--bg3 #191919` · `--line #3d3d3d` · `--fg #fff` · `--fg2 #d6d6d6` · `--fg3 #a6a6a6` · `--accent #ffd400` · `--accent2 #7dff9f` · `--sel #3a3400` · `--code-bg #000` · `--tag-bg #1b1b1b` · `--tag-fg #ffd400` · `--tag-line #4a4200` · syntax `#ffd400 #7dff9f #ff9d5c #9a9a9a #8ecbff #f2f2f2`

### Typography

- **UI font** (`--ui`): `'JetBrains Mono', ui-monospace, monospace` — always monospace, in every mode.
- **Body font** (`--body`): hybrid mode → `'Source Serif 4', Georgia, serif` at `--bodysize: 17.5px` / `--bodylh: 1.72`; mono mode → same as `--ui` at `15px` / `1.7`.
- Fonts loaded from Google Fonts: JetBrains Mono 400/500/600/700, Source Serif 4 400/600/700. Swap for locally hosted files or the codebase's equivalents.
- Type scale in use: `34px` page title (reader h1), `30px` (Diagram h1), `17.5px` body prose, `14.5px` card title, `13.5px` code / map card header / palette row, `13px` sidebar row, `12.5px` card summary + tabs + buttons, `11.5px` reader tag pill, `11px` eyebrow labels, `10.5px` list tag pill + nav number, `9.5px` VISUAL chip.
- Letter-spacing: `-0.025em` large headings, `-0.01em` card titles, `.04em` tabs, `.08em` nav, `.1em`–`.16em` eyebrow/label caps.

### Spacing, radius, shadow

- Spacing steps in use: 1, 2, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 18, 20, 22, 26, 28, 34, 40, 44, 56, 70, 90, 100 px.
- Fixed dimensions: header 56px; sidebar 232px; list 336px (three-pane) / 380px (two-pane); reader max-width 900px (paned) / 820px (centered); prose measure 68ch; palette 620px; map columns min 300px; map grid max-width 1280px.
- Radii: 3px (VISUAL chip), 4px (tags, key chips), 5px (layout icon), 6px (rows, buttons, chips), 7px (header controls, palette rows), 8px (callout), 10px (code block, diagram card), 12px (palette, map card), 26px (floating pill), 999px / 50% (category chips, dots, swatches).
- Borders are always `1px solid var(--line)` unless stated; active accents use a 2px border or a 2–3px left/bottom edge.
- Shadows (only two): palette `0 24px 70px rgba(0,0,0,.45)`; floating pill `0 10px 30px rgba(0,0,0,.28)`.
- Custom scrollbars: `10px` track, thumb `var(--line)` with `6px` radius, transparent track. The header nav hides its scrollbar entirely.

## Screenshots

In `screenshots/`, captured from the prototype at 1440px wide:

| File | Shows |
|---|---|
| `theme-01-midnight-three-pane.png` | Midnight theme, three-pane Browse, Definition tab |
| `theme-02-paper-three-pane.png` | Paper theme |
| `theme-03-sepia-three-pane.png` | Sepia theme |
| `theme-04-ocean-blue-three-pane.png` | Ocean Blue theme |
| `theme-05-high-contrast-three-pane.png` | High Contrast theme |
| `layout-two-pane.png` | Two-pane layout with the category chip rail |
| `layout-centered-reading.png` | Centered reading view + floating jump-to-term pill |
| `reader-code-tab.png` | Code tab: language tabs + highlighted block |
| `page-diagram-concept-map.png` | Diagram page (concept map) |
| `command-palette.png` | Command palette open (Ctrl/Cmd+K) |

All theme shots use the same term (Abstract Class) and layout so palettes can be compared directly.

## Assets

None. No images, no icon set — the few glyphs are Unicode characters used as text: `>` (logo), `⌕` (search), `★` (favorite), `→` (related), `▥ ▤ ▭` (layout icons), `#` (tag prefix). If the codebase has an icon library, substitute equivalents for search / star / layout / arrow and keep the sizes above. `current-app-screenshot.png` is the *before* state, included for context only.

## Files

- `Concept Master.dc.html` — the interactive design reference. All five themes, all three layouts, both type modes, the Diagram page, and the command palette are live in this one file.
- `current-app-screenshot.png` — the app before this rework.
- `screenshots/` — 10 reference captures, listed above.
- `README.md` — this document.
